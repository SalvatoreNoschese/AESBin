const x: number = 1;
export function f(a: string): void {}
